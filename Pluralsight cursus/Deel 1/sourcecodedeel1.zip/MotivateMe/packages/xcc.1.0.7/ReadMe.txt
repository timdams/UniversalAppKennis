﻿XAML CONDITIONAL COMPILATION
============================
Welcome to XCC, a preprocessor adding conditional compilation support to XAML files.

See https://github.com/firstfloorsoftware/xcc for instructions